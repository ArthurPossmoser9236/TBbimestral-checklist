import React, { useState } from 'react';
import '../styles/App.css';
import '../styles/Reset.css';


const daysOfWeek = [
  'Segunda',
  'Terça',
  'Quarta',
  'Quinta',
  'Sexta',
  'Domingo',
];

const subjects = ['Matemática', 'História', 'Física', 'Química', 'Geografia', 'Português', 'Biologia'];

function TaskForm({ onAddTask }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedDays, setSelectedDays] = useState([]);
  const [subject, setSubject] = useState(subjects[0]);

  const handleDayChange = (e) => {
    const day = e.target.value;
    if (e.target.checked) {
      setSelectedDays((prev) => [...prev, day]);
    } else {
      setSelectedDays((prev) => prev.filter((d) => d !== day));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || selectedDays.length === 0 || !subject) {
      alert('Preencha o título, selecione ao menos um dia e escolha a matéria.');
      return;
    }
    onAddTask({ title, description, days: selectedDays, subject });
    setTitle('');
    setDescription('');
    setSelectedDays([]);
    setSubject(subjects[0]);
  };

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="title">Título:</label>
        <input
          id="title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Ex.: Estudar Álgebra"
        />
      </div>

      <div className="form-group">
        <label htmlFor="description">Descrição:</label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Detalhes da atividade..."
        />
      </div>

      <div className="form-group">
        <label>Dias da Semana:</label>
        <div className="checkbox-group">
          {daysOfWeek.map((day) => (
            <label key={day} className="checkbox-label">
              <input
                type="checkbox"
                value={day}
                checked={selectedDays.includes(day)}
                onChange={handleDayChange}
              />
              {day}
            </label>
          ))}
        </div>
      </div>

      <div className="form-group">
        <label htmlFor="subject">Matéria:</label>
        <select id="subject" value={subject} onChange={(e) => setSubject(e.target.value)}>
          {subjects.map((subj) => (
            <option key={subj} value={subj}>
              {subj}
            </option>
          ))}
        </select>
      </div>

      <button type="submit" className="btn-add">Adicionar Tarefa</button>
    </form>
  );
}

export default TaskForm;
