import React from 'react';
import '../styles/App.css';
import '../styles/Reset.css';

const daysOfWeek = [
  '',
  'Segunda',
  'Terça',
  'Quarta',
  'Quinta',
  'Sexta',
  'Sábado',
  'Domingo',
];

const subjects = [
  '',
  'Matemática',
  'História',
  'Física',
  'Química',
  'Geografia',
  'Português',
  'Biologia',
];

function Filters({ dayFilter, subjectFilter, onChangeDayFilter, onChangeSubjectFilter }) {
  return (
    <div className="filters-container">
      <div className="filter-group">
        <label htmlFor="dayFilter">Filtrar por Dia:</label>
        <select
          id="dayFilter"
          value={dayFilter}
          onChange={(e) => onChangeDayFilter(e.target.value)}
        >
          {daysOfWeek.map((day) => (
            <option key={day} value={day}>
              {day === '' ? 'Todos' : day}
            </option>
          ))}
        </select>
      </div>

      <div className="filter-group">
        <label htmlFor="subjectFilter">Filtrar por Matéria:</label>
        <select
          id="subjectFilter"
          value={subjectFilter}
          onChange={(e) => onChangeSubjectFilter(e.target.value)}
        >
          {subjects.map((subj) => (
            <option key={subj} value={subj}>
              {subj === '' ? 'Todas' : subj}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

export default Filters;
