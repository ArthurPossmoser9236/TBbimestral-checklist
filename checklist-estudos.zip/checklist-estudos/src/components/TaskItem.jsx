import React from 'react';
import '../styles/App.css';
import '../styles/Reset.css';

function TaskItem({ task, onToggleComplete, onDelete }) {
  const { id, title, description, days, subject, completed } = task;

  return (
    <li className={`task-item ${completed ? 'completed' : ''}`}>
      <div className="task-header">
        <input
          type="checkbox"
          checked={completed}
          onChange={() => onToggleComplete(id)}
        />
        <h3 className="task-title">{title}</h3>
        <button className="btn-delete" onClick={() => onDelete(id)}>
          Remover
        </button>
      </div>
      {description && <div className="task-desc-div">
        <p className="task-desc">{description}</p>
      </div>}
      <p className="task-info">
        <strong>Dias:</strong> {days.join(', ')}
      </p>
      <p className="task-info">
        <strong>Matéria:</strong> {subject}
      </p>
    </li>
  );
}

export default TaskItem;
