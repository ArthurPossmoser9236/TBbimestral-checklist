import React, { useState, useEffect } from 'react';

import TaskForm from './components/TaskForm';
import Filters from './components/Filters';
import TaskList from './components/TaskList';

import './styles/Reset.css';
import './styles/App.css';

function App() {
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem('studyTasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [dayFilter, setDayFilter] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');

  useEffect(() => {
    localStorage.setItem('studyTasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (taskData) => {
    const newTask = {
      id: Date.now(),
      title: taskData.title,
      description: taskData.description,
      days: taskData.days,
      subject: taskData.subject,
      completed: false,
    };
    setTasks((prev) => [...prev, newTask]);
  };

  const toggleComplete = (id) => {
    setTasks((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, completed: !t.completed } : t
      )
    );
  };

  const deleteTask = (id) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const filteredTasks = tasks.filter((task) => {
    const matchesDay = dayFilter ? task.days.includes(dayFilter) : true;
    const matchesSubject = subjectFilter ? task.subject === subjectFilter : true;
    return matchesDay && matchesSubject;
  });

  return (
    <div className="app-container">
      <h1 className="app-title">Checklist de Estudos</h1>

      <TaskForm onAddTask={addTask} />

      <Filters
        dayFilter={dayFilter}
        subjectFilter={subjectFilter}
        onChangeDayFilter={setDayFilter}
        onChangeSubjectFilter={setSubjectFilter}
      />

      <TaskList
        tasks={filteredTasks}
        onToggleComplete={toggleComplete}
        onDelete={deleteTask}
      />
    </div>
  );
}

export default App;
